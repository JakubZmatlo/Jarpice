import './MaskGroup.css'

export default function MaskGroup() {
  return (
    <div className="mask-group">
      <div className="image-4">
      </div>
    </div>
  )
}