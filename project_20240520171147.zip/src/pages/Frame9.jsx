import './Frame9.css'

export default function Frame9() {
  return (
    <div className="frame-9">
      <div className="aktuality">
               Aktuality
      </div>
      <span className="revize-kontroly-aitn-komn-akotl-dovolen-administrativa-1642024-vte-jarpice">
      Revize, kontroly a čištění komínů a kotlů<br />
      <br />
      Dovolená-administrativa<br />
      <br />
      16. 4. 2024<br />
      VTE JARPICE
      </span>
    </div>
  )
}